#include <18f4550.h>
#fuses HSPLL,PLL5,CPUDIV1,NOWDT,NOPROTECT,NOLVP,NODEBUG
#use delay(clock=48M)//20 Megas cristal fisico
#use i2c(SLAVE, SDA=PIN_B0, SCL=PIN_B1, address=0xA0)
#use fast_io(D)
#use fast_io(C)
int  buffer[3];
#INT_SSP
void ssp_interupt (){
   BYTE incoming, state;
   state = i2c_isr_state();
      incoming = i2c_read(1);
      
      if(state==1){
      buffer[1]=incoming;
      output_d(buffer[1]);     
      }    
     else if(state==2){
      buffer[2]=(incoming<<6);
      output_c(buffer[2]);
      }    
}
void main ()
{
   set_tris_d(0X00);
   set_tris_c(0X00);
   enable_interrupts(INT_SSP);
   enable_interrupts(GLOBAL);
   while (TRUE) {
output_d(buffer[1]);
output_c(buffer[2]);
   }
}
