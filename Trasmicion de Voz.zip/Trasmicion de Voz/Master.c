#include <18f4550.h>
#device adc=10
#fuses HSPLL,PLL5,CPUDIV1,NOWDT,NOPROTECT,NOLVP,NODEBUG
#use delay(clock=48M)//20 Megas cristal fisico
#use I2C(master, SDA=PIN_B0, SCL=PIN_B1,Fast=450000)
#use fast_io(A)
int8 dato;
void main(){
set_tris_a(0X00);
setup_adc_ports(AN0);
setup_adc(ADC_clock_DIV_2);
set_adc_channel(0);
delay_us(10);
dato=read_adc();
delay_us(10);
while (true){
dato=read_adc();
i2c_start();
i2c_write(0xA0);     // Device address
i2c_write(dato);
i2c_write(dato>>8); 
i2c_stop();
}}
